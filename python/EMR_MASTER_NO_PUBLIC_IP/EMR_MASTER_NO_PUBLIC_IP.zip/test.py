import json
import datetime
import boto3
import botocore
client = boto3.client('emr',region_name="us-east-1")
ec2=boto3.client('ec2',region_name="us_east_1")
cluster_id="j-3O7EFMACWFJD9"
response = client.list_instances(ClusterId=cluster_id,InstanceGroupTypes=['MASTER'])["Instances"][0]
print(response)
test=response['PublicDnsName']
if not test:
        print("C")
print(test)


clusters = client.list_clusters(ClusterStates=['RUNNING'|'WAITING'])
        all_clusters = []
        while True:
                all_clusters += clusters['Clusters']
                if "Marker" in clusters:
                        clusters = client.list_clusters(ClusterStates=['RUNNING'|'WAITING'],Marker=clusters["Marker"])
                else:
                        break
        return all_clusters


for cluster in cluster_list:
        cluster_id = cluster["Id"]
        response = client.list_instances(ClusterId=cluster_id,InstanceGroupTypes=['MASTER'])["Instances"][0]
        my_cluster_instance_dict = {}
        my_cluster_instance_dict[cluster_id]=response["Ec2InstanceId"]
        ec2respons=ec2.describe_instances(InstanceIds=my_cluster_instance_dict.values())
        print(ec2respons)


some_dict = {}
some_dict["a"] = "b"
some_dict[3] = 4
vals=some_dict.values()
print(vals)
for i in vals:
        print(i)
